﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOC_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Close button
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Clicking the convert button changes the appearance of the name input by the user-
        /// The user will select how he/she wants the name altered and the program outputs those changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvert_Click(object sender, EventArgs e)
        {
          //Variables
            int fontIndex = indexFont.SelectedIndex;
            string name = txtInput.Text;
          //--------------------------------------------------------------------------------------
          //Font selector group box
            switch (fontIndex)
            {
                case 0:
                    lblOutput.Font = new Font("Calibri", lblOutput.Font.Size);
                    lblOutput.Text = name;
                    break;

                case 1:
                    lblOutput.Font = new Font("Comic Sans MS", lblOutput.Font.Size);
                    lblOutput.Text = name;
                    break;

                case 2:
                    lblOutput.Font = new Font("Arial", lblOutput.Font.Size);
                    lblOutput.Text = name;
                    break;

                case 3:
                    lblOutput.Font = new Font("Times New Roman", lblOutput.Font.Size);
                    lblOutput.Text = name;
                    break;
            }
            //----------------------------------------------------------------------------------
            //Color selector radio buttons 
            if (radbtnBlue.Checked)
            {
                Random rnd = new Random();
                lblOutput.ForeColor = System.Drawing.Color.Blue;
            }
            if (radbtnRed.Checked)
            {
                Random rnd = new Random();
                lblOutput.ForeColor = System.Drawing.Color.Red;
            }
            if (radbtnGreen.Checked)
            {
                Random rnd = new Random();
                lblOutput.ForeColor = System.Drawing.Color.Green;
            }
            if (radbtnYellow.Checked)
            {
                Random rnd = new Random();
                lblOutput.ForeColor = System.Drawing.Color.Yellow;
            }
            //---------------------------------------------------------------------------------
            //Bold/Italic selector check boxes
            if (cbBold.Checked)
            {
                lblOutput.Font = new Font(lblOutput.Font.Name, 16, FontStyle.Bold);
            }
            if (cbItalic.Checked)
            {
                lblOutput.Font = new Font(lblOutput.Font.Name, 16, FontStyle.Italic);
            }
            if (cbBold.Checked & cbItalic.Checked)
            {
                lblOutput.Font = new Font(lblOutput.Font.Name, 16, FontStyle.Bold | FontStyle.Italic);
            }

            lblOutput.Text = name;

        }

        //Clear button
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Text = string.Empty;
            lblOutput.Text = string.Empty;
        }
    }
}
