﻿namespace OOC_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.indexFont = new System.Windows.Forms.ListBox();
            this.gbColor = new System.Windows.Forms.GroupBox();
            this.radbtnYellow = new System.Windows.Forms.RadioButton();
            this.radbtnGreen = new System.Windows.Forms.RadioButton();
            this.radbtnRed = new System.Windows.Forms.RadioButton();
            this.radbtnBlue = new System.Windows.Forms.RadioButton();
            this.gbBldItl = new System.Windows.Forms.GroupBox();
            this.cbItalic = new System.Windows.Forms.CheckBox();
            this.cbBold = new System.Windows.Forms.CheckBox();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.gbColor.SuspendLayout();
            this.gbBldItl.SuspendLayout();
            this.SuspendLayout();
            // 
            // indexFont
            // 
            this.indexFont.FormattingEnabled = true;
            this.indexFont.ItemHeight = 16;
            this.indexFont.Items.AddRange(new object[] {
            "Calibri",
            "Comic Sans",
            "Arial",
            "Times New Roman"});
            this.indexFont.Location = new System.Drawing.Point(29, 92);
            this.indexFont.Name = "indexFont";
            this.indexFont.Size = new System.Drawing.Size(126, 84);
            this.indexFont.TabIndex = 0;
            this.indexFont.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // gbColor
            // 
            this.gbColor.Controls.Add(this.radbtnYellow);
            this.gbColor.Controls.Add(this.radbtnGreen);
            this.gbColor.Controls.Add(this.radbtnRed);
            this.gbColor.Controls.Add(this.radbtnBlue);
            this.gbColor.Location = new System.Drawing.Point(29, 182);
            this.gbColor.Name = "gbColor";
            this.gbColor.Size = new System.Drawing.Size(200, 133);
            this.gbColor.TabIndex = 1;
            this.gbColor.TabStop = false;
            this.gbColor.Text = "Select Color";
            // 
            // radbtnYellow
            // 
            this.radbtnYellow.AutoSize = true;
            this.radbtnYellow.Location = new System.Drawing.Point(7, 106);
            this.radbtnYellow.Name = "radbtnYellow";
            this.radbtnYellow.Size = new System.Drawing.Size(69, 21);
            this.radbtnYellow.TabIndex = 3;
            this.radbtnYellow.TabStop = true;
            this.radbtnYellow.Text = "Yellow";
            this.radbtnYellow.UseVisualStyleBackColor = true;
            // 
            // radbtnGreen
            // 
            this.radbtnGreen.AutoSize = true;
            this.radbtnGreen.Location = new System.Drawing.Point(7, 78);
            this.radbtnGreen.Name = "radbtnGreen";
            this.radbtnGreen.Size = new System.Drawing.Size(69, 21);
            this.radbtnGreen.TabIndex = 2;
            this.radbtnGreen.TabStop = true;
            this.radbtnGreen.Text = "Green";
            this.radbtnGreen.UseVisualStyleBackColor = true;
            // 
            // radbtnRed
            // 
            this.radbtnRed.AutoSize = true;
            this.radbtnRed.Location = new System.Drawing.Point(7, 50);
            this.radbtnRed.Name = "radbtnRed";
            this.radbtnRed.Size = new System.Drawing.Size(55, 21);
            this.radbtnRed.TabIndex = 1;
            this.radbtnRed.TabStop = true;
            this.radbtnRed.Text = "Red";
            this.radbtnRed.UseVisualStyleBackColor = true;
            // 
            // radbtnBlue
            // 
            this.radbtnBlue.AutoSize = true;
            this.radbtnBlue.Location = new System.Drawing.Point(7, 22);
            this.radbtnBlue.Name = "radbtnBlue";
            this.radbtnBlue.Size = new System.Drawing.Size(57, 21);
            this.radbtnBlue.TabIndex = 0;
            this.radbtnBlue.TabStop = true;
            this.radbtnBlue.Text = "Blue";
            this.radbtnBlue.UseVisualStyleBackColor = true;
            // 
            // gbBldItl
            // 
            this.gbBldItl.Controls.Add(this.cbItalic);
            this.gbBldItl.Controls.Add(this.cbBold);
            this.gbBldItl.Location = new System.Drawing.Point(29, 321);
            this.gbBldItl.Name = "gbBldItl";
            this.gbBldItl.Size = new System.Drawing.Size(200, 81);
            this.gbBldItl.TabIndex = 2;
            this.gbBldItl.TabStop = false;
            this.gbBldItl.Text = "Select Details";
            // 
            // cbItalic
            // 
            this.cbItalic.AutoSize = true;
            this.cbItalic.Location = new System.Drawing.Point(7, 50);
            this.cbItalic.Name = "cbItalic";
            this.cbItalic.Size = new System.Drawing.Size(58, 21);
            this.cbItalic.TabIndex = 1;
            this.cbItalic.Text = "Italic";
            this.cbItalic.UseVisualStyleBackColor = true;
            // 
            // cbBold
            // 
            this.cbBold.AutoSize = true;
            this.cbBold.Location = new System.Drawing.Point(7, 22);
            this.cbBold.Name = "cbBold";
            this.cbBold.Size = new System.Drawing.Size(58, 21);
            this.cbBold.TabIndex = 0;
            this.cbBold.Text = "Bold";
            this.cbBold.UseVisualStyleBackColor = true;
            // 
            // btnConvert
            // 
            this.btnConvert.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnConvert.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConvert.Location = new System.Drawing.Point(292, 199);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(137, 54);
            this.btnConvert.TabIndex = 3;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = false;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnExit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(292, 343);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(137, 54);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Choose a font:";
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(29, 43);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(175, 22);
            this.txtInput.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Please enter your name:";
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(286, 92);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(0, 32);
            this.lblOutput.TabIndex = 8;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClear.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(292, 272);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(137, 52);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 445);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.gbBldItl);
            this.Controls.Add(this.gbColor);
            this.Controls.Add(this.indexFont);
            this.Name = "Form1";
            this.Text = "Name Stylizer ";
            this.gbColor.ResumeLayout(false);
            this.gbColor.PerformLayout();
            this.gbBldItl.ResumeLayout(false);
            this.gbBldItl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox indexFont;
        private System.Windows.Forms.GroupBox gbColor;
        private System.Windows.Forms.RadioButton radbtnRed;
        private System.Windows.Forms.RadioButton radbtnBlue;
        private System.Windows.Forms.GroupBox gbBldItl;
        private System.Windows.Forms.CheckBox cbItalic;
        private System.Windows.Forms.CheckBox cbBold;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radbtnYellow;
        private System.Windows.Forms.RadioButton radbtnGreen;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnClear;
    }
}

