﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inClassAssignment4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Calculating Days, Hours, and Minutes from seconds.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bttnFindOut_Click(object sender, EventArgs e)
        {
            //Input Validation
            if (string.IsNullOrEmpty(txtElapsedSeconds.Text))
            {
                lblOutput.Text = "Please enter the ammount of seconds.";
            }
            else
            {

                //Take in variables
                int inputSeconds = Convert.ToInt32(txtElapsedSeconds.Text);
                int outputMinutes = 0;
                int outputHours = 0;
                int outputDays = 0;

                if (inputSeconds < 60)
                {
                    lblOutput.Text = "The number of seconds is " + inputSeconds + ".";
                }

                else if (inputSeconds >= 60 & inputSeconds < 3600)
                {
                    outputMinutes = inputSeconds / 60;
                    lblOutput.Text = "The number of minutes is " + outputMinutes + ".";

                }

                else if (inputSeconds >= 3600 & inputSeconds < 86400)
                {
                    outputHours = inputSeconds / 3600;
                    lblOutput.Text = "The number of hours is " + outputHours + ".";
                }

                else if (inputSeconds >= 86400)
                {
                    outputDays = inputSeconds / 86400;
                    lblOutput.Text = "The nuber of days is " + outputDays + ".";
                }

            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listShape_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
