﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Zac Almas
//CST-117
//11/25/20
//Tic Tac Toe program for Out of Class Assignment 4
namespace OutOfClass4
{
    public partial class TicTacToe : Form
    {
        public TicTacToe()
        {
            InitializeComponent();
        }

        /// <summary>
        /// When this button is clicked a new tic tac toe game will be generated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewGame_Click(object sender, EventArgs e)
        {
            //Define variables
            int[,] game = new int[3,3];
            string[,] xAndO = new string[3, 3];
            string winner = "";

            //Create a RNG that will tell the computer to put in a X or O
            Random rng = new Random();

            //For loop that creates the game
            //Outer loop that interates through the rows
            for (int row = 0; row < game.GetLength(0); row++)
            {
                //Inner loop that interates through the columns 
                for (int col = 0; col < game.GetLength(1); col++)
                {
                    //Insert into array
                    game[row, col] = rng.Next(0, 2);
                    
                    if (game[row, col] == 1)
                    {
                        xAndO[row, col] = "X";
                    }
                    else
                    {
                        xAndO[row, col] = "O";
                    }

                }

            }

            //Display Game Board
            lblA1.Text = xAndO[0, 0];
            lblA2.Text = xAndO[1, 0];
            lblA3.Text = xAndO[2, 0];
            lblB1.Text = xAndO[0, 1];
            lblB2.Text = xAndO[1, 1];
            lblB3.Text = xAndO[2, 1];
            lblC1.Text = xAndO[0, 2];
            lblC2.Text = xAndO[1, 2];
            lblC3.Text = xAndO[2, 2];

            //Checks to see who won
            Brain checkWin = new Brain();
            int win = checkWin.WinCheck(game);

            if (win == 0)
            {
                winner = "O wins!";
            }
            if (win == 1)
            {
                winner = "X wins!";
            }
            if (win == 2)
            {
                winner = "It's a draw!";
            }

            lblWinner.Text = winner;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TicTacToe_Load(object sender, EventArgs e)
        {

        }
    }
}
