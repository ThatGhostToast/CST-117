﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace OutOfClass4
{
    public class Brain
    {

        public int WinCheck(int[,] gameBoard)
        {
            int win = 2;
            //If it returns 2, its a draw
            //If it returns 1, X wins
            //If it returns 0, O wins

            //Check if X wins
            //Check rows
            if(gameBoard[0,0] == 1 && gameBoard[0,1] == 1 && gameBoard[0,2] == 1)
            {
                win = 1;
            }

            if (gameBoard[1, 0] == 1 && gameBoard[1, 1] == 1 && gameBoard[1, 2] == 1)
            {
                win = 1;
            }

            if (gameBoard[2, 0] == 1 && gameBoard[2, 1] == 1 && gameBoard[2, 2] == 1)
            {
                win = 1;
            }

            //Check Columns
            if (gameBoard[0, 0] == 1 && gameBoard[1, 0] == 1 && gameBoard[2, 0] == 1)
            {
                win = 1;
            }

            if (gameBoard[0, 1] == 1 && gameBoard[1, 1] == 1 && gameBoard[2, 1] == 1)
            {
                win = 1;
            }

            if (gameBoard[0, 2] == 1 && gameBoard[1, 2] == 1 && gameBoard[2, 2] == 1)
            {
                win = 1;
            }

            //Check Angles
            if (gameBoard[0,0] == 1 && gameBoard[1,1] == 1 && gameBoard[2,2] == 1)
            {
                win = 1;
            }

            if (gameBoard[0, 2] == 1 && gameBoard[1, 1] == 1 && gameBoard[2, 0] == 1)
            {
                win = 1;
            }

            //------------------------------------------------------------------------
            //Check if O wins 
            //Check rows
            if (gameBoard[0, 0] == 0 && gameBoard[0, 1] == 0 && gameBoard[0, 2] == 0)
            {
                win = 0;
            }

            if (gameBoard[1, 0] == 0 && gameBoard[1, 1] == 0 && gameBoard[1, 2] == 0)
            {
                win = 0;
            }

            if (gameBoard[2, 0] == 0 && gameBoard[2, 1] == 0 && gameBoard[2, 2] == 0)
            {
                win = 0;
            }

            //Check Columns
            if (gameBoard[0, 0] == 0 && gameBoard[1, 0] == 0 && gameBoard[2, 0] == 0)
            {
                win = 0;
            }

            if (gameBoard[0, 1] == 0 && gameBoard[1, 1] == 0 && gameBoard[2, 1] == 0)
            {
                win = 0;
            }

            if (gameBoard[0, 2] == 0 && gameBoard[1, 2] == 0 && gameBoard[2, 2] == 0)
            {
                win = 0;
            }

            //Check Angles
            if (gameBoard[0, 0] == 0 && gameBoard[1, 1] == 0 && gameBoard[2, 2] == 0)
            {
                win = 0;
            }

            if (gameBoard[0, 2] == 0 && gameBoard[1, 1] == 0 && gameBoard[2, 0] == 0)
            {
                win = 0;
            }

            return win;
        }
    }
}
