﻿namespace OutOfClass4
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicTacToe));
            this.btnNewGame = new System.Windows.Forms.Button();
            this.lblA1 = new System.Windows.Forms.Label();
            this.lblB1 = new System.Windows.Forms.Label();
            this.lblC1 = new System.Windows.Forms.Label();
            this.lblA2 = new System.Windows.Forms.Label();
            this.lblB2 = new System.Windows.Forms.Label();
            this.lblC2 = new System.Windows.Forms.Label();
            this.lblA3 = new System.Windows.Forms.Label();
            this.lblB3 = new System.Windows.Forms.Label();
            this.lblC3 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblWinner = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnNewGame
            // 
            this.btnNewGame.Location = new System.Drawing.Point(72, 249);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(81, 43);
            this.btnNewGame.TabIndex = 0;
            this.btnNewGame.Text = "New Game!";
            this.btnNewGame.UseVisualStyleBackColor = true;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // lblA1
            // 
            this.lblA1.AutoSize = true;
            this.lblA1.BackColor = System.Drawing.Color.White;
            this.lblA1.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA1.Location = new System.Drawing.Point(61, 44);
            this.lblA1.Name = "lblA1";
            this.lblA1.Size = new System.Drawing.Size(50, 56);
            this.lblA1.TabIndex = 1;
            this.lblA1.Text = "  ";
            // 
            // lblB1
            // 
            this.lblB1.AutoSize = true;
            this.lblB1.BackColor = System.Drawing.Color.White;
            this.lblB1.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB1.Location = new System.Drawing.Point(132, 44);
            this.lblB1.Name = "lblB1";
            this.lblB1.Size = new System.Drawing.Size(50, 56);
            this.lblB1.TabIndex = 2;
            this.lblB1.Text = "  ";
            // 
            // lblC1
            // 
            this.lblC1.AutoSize = true;
            this.lblC1.BackColor = System.Drawing.Color.White;
            this.lblC1.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC1.Location = new System.Drawing.Point(206, 44);
            this.lblC1.Name = "lblC1";
            this.lblC1.Size = new System.Drawing.Size(50, 56);
            this.lblC1.TabIndex = 3;
            this.lblC1.Text = "  ";
            // 
            // lblA2
            // 
            this.lblA2.AutoSize = true;
            this.lblA2.BackColor = System.Drawing.Color.White;
            this.lblA2.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA2.Location = new System.Drawing.Point(61, 112);
            this.lblA2.Name = "lblA2";
            this.lblA2.Size = new System.Drawing.Size(50, 56);
            this.lblA2.TabIndex = 4;
            this.lblA2.Text = "  ";
            // 
            // lblB2
            // 
            this.lblB2.AutoSize = true;
            this.lblB2.BackColor = System.Drawing.Color.White;
            this.lblB2.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB2.Location = new System.Drawing.Point(132, 112);
            this.lblB2.Name = "lblB2";
            this.lblB2.Size = new System.Drawing.Size(50, 56);
            this.lblB2.TabIndex = 5;
            this.lblB2.Text = "  ";
            // 
            // lblC2
            // 
            this.lblC2.AutoSize = true;
            this.lblC2.BackColor = System.Drawing.Color.White;
            this.lblC2.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC2.Location = new System.Drawing.Point(206, 112);
            this.lblC2.Name = "lblC2";
            this.lblC2.Size = new System.Drawing.Size(50, 56);
            this.lblC2.TabIndex = 6;
            this.lblC2.Text = "  ";
            // 
            // lblA3
            // 
            this.lblA3.AutoSize = true;
            this.lblA3.BackColor = System.Drawing.Color.White;
            this.lblA3.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA3.Location = new System.Drawing.Point(61, 178);
            this.lblA3.Name = "lblA3";
            this.lblA3.Size = new System.Drawing.Size(50, 56);
            this.lblA3.TabIndex = 7;
            this.lblA3.Text = "  ";
            // 
            // lblB3
            // 
            this.lblB3.AutoSize = true;
            this.lblB3.BackColor = System.Drawing.Color.White;
            this.lblB3.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB3.Location = new System.Drawing.Point(132, 178);
            this.lblB3.Name = "lblB3";
            this.lblB3.Size = new System.Drawing.Size(50, 56);
            this.lblB3.TabIndex = 8;
            this.lblB3.Text = "  ";
            // 
            // lblC3
            // 
            this.lblC3.AutoSize = true;
            this.lblC3.BackColor = System.Drawing.Color.White;
            this.lblC3.Font = new System.Drawing.Font("Arial", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC3.Location = new System.Drawing.Point(206, 178);
            this.lblC3.Name = "lblC3";
            this.lblC3.Size = new System.Drawing.Size(50, 56);
            this.lblC3.TabIndex = 9;
            this.lblC3.Text = "  ";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(159, 249);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(81, 43);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblWinner
            // 
            this.lblWinner.AutoSize = true;
            this.lblWinner.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinner.Location = new System.Drawing.Point(65, 313);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(0, 40);
            this.lblWinner.TabIndex = 11;
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(313, 402);
            this.Controls.Add(this.lblWinner);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblC3);
            this.Controls.Add(this.lblB3);
            this.Controls.Add(this.lblA3);
            this.Controls.Add(this.lblC2);
            this.Controls.Add(this.lblB2);
            this.Controls.Add(this.lblA2);
            this.Controls.Add(this.lblC1);
            this.Controls.Add(this.lblB1);
            this.Controls.Add(this.lblA1);
            this.Controls.Add(this.btnNewGame);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TicTacToe";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.TicTacToe_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Label lblA1;
        private System.Windows.Forms.Label lblB1;
        private System.Windows.Forms.Label lblC1;
        private System.Windows.Forms.Label lblA2;
        private System.Windows.Forms.Label lblB2;
        private System.Windows.Forms.Label lblC2;
        private System.Windows.Forms.Label lblA3;
        private System.Windows.Forms.Label lblB3;
        private System.Windows.Forms.Label lblC3;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblWinner;
    }
}

